#!/bin/sh
# Lampen-Gateway: übersetzt MQTT-Befehle in Befehle für eine Hue-Lampe.
# Ohne HUE_IP läuft es als Simulation und schreibt nur ins Log.
#
#   zuhause/lampe/set       an, aus, blinken, warm, rot, gruen, blau, gelb, lila
#   zuhause/lampe/zustand   der zuletzt ausgeführte Befehl (gespeichert)
#
# Zusätzliche Aufrufe:
#   docker compose run --rm lampe koppeln   Schlüssel von der Hue Bridge holen
#   docker compose run --rm lampe lampen    Lampen der Bridge mit Nummer anzeigen

BROKER="${MQTT_HOST:-broker}"

# Ein HTTP-Befehl an die Bridge, so wie ihn auch die Hue-App schickt.
# Das sleep hält die Leitung offen, bis die Antwort der Bridge da ist.
hue() {
  {
    printf 'PUT /api/%s/lights/%s/state HTTP/1.1\r\nHost: %s\r\nContent-Type: application/json\r\nContent-Length: %s\r\nConnection: close\r\n\r\n%s' \
      "$HUE_KEY" "$HUE_LAMPE" "$HUE_IP" "${#1}" "$1"
    sleep 1
  } | nc -w 3 "$HUE_IP" 80 | tail -n 1
  echo
}

case "$1" in
  koppeln)
    if [ -z "$HUE_IP" ]; then echo "HUE_IP fehlt in der .env."; exit 1; fi
    echo "Drückt jetzt den runden Knopf auf der Hue Bridge. Ich frage 30 Sekunden lang nach."
    for i in 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15; do
      antwort=$(wget -qO- --post-data '{"devicetype":"zuhause#gateway"}' "http://$HUE_IP/api")
      case "$antwort" in
        *username*)
          echo "$antwort" | sed 's/.*"username":"\([^"]*\)".*/HUE_KEY=\1/'
          echo "Diese Zeile in die .env übernehmen."
          exit 0 ;;
      esac
      sleep 2
    done
    echo "Kein Knopfdruck erkannt. Den Befehl wiederholen und dabei den Knopf drücken."
    exit 1 ;;
  lampen)
    if [ -z "$HUE_IP" ] || [ -z "$HUE_KEY" ]; then echo "HUE_IP und HUE_KEY fehlen in der .env."; exit 1; fi
    wget -qO- "http://$HUE_IP/api/$HUE_KEY/lights" \
      | sed 's/"\([0-9]*\)":{"state"/\n\1 {"state"/g' \
      | sed -n 's/^\([0-9]*\) .*"name":"\([^"]*\)".*/Lampe \1: \2/p'
    exit 0 ;;
esac

if [ -n "$HUE_IP" ]; then
  echo "Lampen-Gateway startet: Broker $BROKER, Hue Bridge $HUE_IP, Lampe $HUE_LAMPE"
else
  echo "Lampen-Gateway startet als Simulation: Broker $BROKER, keine Hue Bridge eingetragen"
fi

while true; do
  mosquitto_sub -h "$BROKER" -u "$MQTT_USER" -P "$MQTT_PASS" -t zuhause/lampe/set | while read -r befehl; do
    case "$befehl" in
      an)    zustand='{"on":true}' ;;
      aus)   zustand='{"on":false}' ;;
      blinken) zustand='{"alert":"lselect"}' ;;
      warm)  zustand='{"on":true,"ct":370,"bri":180}' ;;
      rot)   zustand='{"on":true,"hue":0,"sat":254,"bri":254}' ;;
      gruen) zustand='{"on":true,"hue":21845,"sat":254,"bri":254}' ;;
      blau)  zustand='{"on":true,"hue":46920,"sat":254,"bri":254}' ;;
      gelb)  zustand='{"on":true,"hue":10923,"sat":254,"bri":254}' ;;
      lila)  zustand='{"on":true,"hue":50000,"sat":254,"bri":254}' ;;
      *)     echo "$(date +%H:%M:%S)  unbekannter Befehl: $befehl"; continue ;;
    esac
    if [ -n "$HUE_IP" ]; then
      echo "$(date +%H:%M:%S)  $befehl, Antwort der Bridge: $(hue "$zustand")"
    else
      echo "$(date +%H:%M:%S)  $befehl (Simulation, keine Lampe angesprochen)"
    fi
    mosquitto_pub -h "$BROKER" -u "$MQTT_USER" -P "$MQTT_PASS" -t zuhause/lampe/zustand -m "$befehl" -r
  done
  echo "$(date +%H:%M:%S)  Keine Verbindung zum Broker, neuer Versuch in 5 Sekunden"
  sleep 5
done

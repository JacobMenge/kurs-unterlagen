#!/bin/sh
# Ofen-Sensor: meldet alle paar Sekunden eine simulierte Ofentemperatur per MQTT.
# Alle Einstellungen kommen als Umgebungsvariablen, z. B. docker run -e TEAM=rot ...

# Pflichtangaben prüfen
if [ -z "$TEAM" ]; then
  echo "TEAM fehlt. Beispiel: -e TEAM=rot"
  exit 1
fi
if [ -z "$MQTT_HOST" ]; then
  echo "MQTT_HOST fehlt. Beispiel: -e MQTT_HOST=broker.example.org"
  exit 1
fi

# Standardwerte, falls nichts anderes angegeben ist
MQTT_PORT="${MQTT_PORT:-8883}"
TLS="${TLS:-1}"
INTERVALL="${INTERVALL:-5}"
TOPIC="kurs/$TEAM/ofen/temperatur"

# Schalter für mosquitto_pub sammeln. set -- legt die Liste an, "$@" setzt sie später ein.
set -- -h "$MQTT_HOST" -p "$MQTT_PORT" -t "$TOPIC"
if [ "$TLS" = "0" ]; then
  VERBINDUNG="ohne TLS"
else
  set -- "$@" --tls-use-os-certs
  VERBINDUNG="mit TLS"
fi
# Anmeldung nur mitschicken, wenn sie angegeben ist
if [ -n "$MQTT_USER" ]; then
  set -- "$@" -u "$MQTT_USER"
fi
if [ -n "$MQTT_PASS" ]; then
  set -- "$@" -P "$MQTT_PASS"
fi

# Strg+C und docker stop beenden den Sensor sauber
trap 'exit 0' INT TERM

echo "Ofen-Sensor startet: Broker $MQTT_HOST:$MQTT_PORT $VERBINDUNG, Topic $TOPIC, Intervall $INTERVALL s"

# Temperatur in Zehntelgrad als Ganzzahl: 1800 steht für 180,0 °C
TEMP=1800

while true; do
  WERT="$((TEMP / 10)).$((TEMP % 10))"
  NACHRICHT=$(printf '{"wert": %s, "einheit": "C"}' "$WERT")

  if mosquitto_pub "$@" -m "$NACHRICHT"; then
    echo "$(date +%H:%M:%S)  $TOPIC  $WERT °C"
    sleep "$INTERVALL"
  else
    echo "$(date +%H:%M:%S)  Senden fehlgeschlagen, neuer Versuch in 5 Sekunden"
    sleep 5
  fi

  # Nächster Wert: Der Ofen heizt in Schritten von 6 Grad auf.
  # Ab 225,0 °C schwankt die Temperatur zufällig zwischen 224,0 und 232,9 °C.
  if [ "$TEMP" -lt 2250 ]; then
    TEMP=$((TEMP + 60))
  else
    TEMP=$((2240 + RANDOM % 90))
  fi
done
